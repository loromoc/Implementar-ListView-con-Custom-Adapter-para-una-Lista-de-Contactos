package com.example.listviewconcustomadapter


class ContactModel (
    val nombre: String,
    val telefono: String,
    val email: String,
    val imageId: Int
)
{

}